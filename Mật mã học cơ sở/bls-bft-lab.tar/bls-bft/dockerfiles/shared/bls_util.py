def fake_sign(msg): return "sig:" + msg
def fake_verify(sig, msg): return sig == "sig:" + msg

