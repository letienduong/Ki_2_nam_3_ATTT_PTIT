#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket, json, time
from shared import bls_util

sk, pk = bls_util.generate_key("validator1")

block = {
    "id": "block-99",
    "data": "Transaction from validator1",
    "timestamp": time.time()
}
msg = json.dumps(block).encode()
sig = bls_util.sign(sk, msg)

s = socket.socket()
s.connect(("validator2", 12345))
s.send(json.dumps({"block": block, "sig": sig}).encode())
s.close()

