print("Hello from validator1")
with open("validator1.log", "w") as f:
    f.write("Block signed\n")

