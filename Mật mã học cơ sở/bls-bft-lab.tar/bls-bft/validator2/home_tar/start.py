print("Hello from validator2")
with open("validator2.log", "w") as f:
    f.write("QC success\n")

