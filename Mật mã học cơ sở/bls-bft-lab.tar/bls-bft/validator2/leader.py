#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket, json
from shared import bls_util

signatures = []
seen_blocks = {}

LOGFILE = "leader.log"

def log(msg):
    print(msg)
    with open(LOGFILE, "a") as f:
        f.write(msg + "\n")

server = socket.socket()
server.bind(('', 12345))
server.listen(5)

log("[leader] Listening for incoming signatures...")

while True:
    conn, _ = server.accept()
    data = conn.recv(4096)
    obj = json.loads(data.decode())

    block = obj["block"]
    sig = obj["sig"]
    msg = json.dumps(block, sort_keys=True).encode()
    block_id = block["id"]

    # Phát hiện mạo danh nếu block ID giống nhưng nội dung khác
    if block_id in seen_blocks:
        if seen_blocks[block_id] != msg:
            log("Forged signature detected for block ID: {}".format(block_id))
    else:
        seen_blocks[block_id] = msg

    log("Received signature for block ID: {}".format(block_id))
    signatures.append(sig)

    if len(signatures) >= 2:
        agg_sig = bls_util.aggregate(signatures)
        log("Quorum Certificate created with aggregate: {}".format(agg_sig))
        break

