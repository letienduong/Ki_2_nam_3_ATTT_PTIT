#!/usr/bin/env python3
import hashlib

def generate_key(seed):
    sk = seed
    pk = hashlib.sha256(seed.encode()).hexdigest()
    return sk, pk

def sign(sk, message):
    return hashlib.sha256((sk + message.decode()).encode()).hexdigest()

def verify(pk, message, signature):
    expected = hashlib.sha256((pk + message.decode()).encode()).hexdigest()
    return expected == signature

def aggregate(signatures):
    return '|'.join(signatures)

