#!/usr/bin/env python3
import json
import hashlib

def hash_block(block_dict):
    block_string = json.dumps(block_dict, sort_keys=True).encode()
    return hashlib.sha256(block_string).hexdigest()



