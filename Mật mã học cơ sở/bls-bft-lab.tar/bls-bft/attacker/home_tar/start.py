print("Hello from attacker")
with open("attacker.log", "w") as f:
    f.write("Replay detected\n")

