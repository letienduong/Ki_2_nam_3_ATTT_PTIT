#!/usr/bin/env python3
import socket, json, time
from shared import bls_util

sk_fake = "validator1"

fake_block = {
    "id": ,
    "data": "MALICIOUS DATA from attacker",
    "timestamp": time.time()
}
msg = json.dumps(fake_block).encode()
sig = bls_util.sign(sk_fake, msg)

try:
    s = socket.socket()
    s.connect(("validator2", 12345))
    s.send(json.dumps({"block": fake_block, "sig": sig}).encode())
    s.close()

    with open("attacker.log", "w") as f:
        f.write("[attacker] Sent fake block at {}\n".format(time.ctime()))
        f.write("Block ID: {}\n".format(fake_block["id"]))
        f.write("Block data: {}\n".format(fake_block["data"]))

except Exception as e:
    with open("attacker.log", "w") as f:
        f.write("[attacker] Failed to send block at {}\n".format(time.ctime()))
        f.write("Error: {}\n".format(str(e)))
